import "./validadorGlobal.js";
import autores from "./Autor.js";
import livros from "./Livro.js";

export { autores, livros };